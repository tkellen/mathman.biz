vti_encoding:SR|utf8-nl
vti_timelastmodified:TW|18 Jun 2010 05:00:00 -0000
vti_author:SR|MATHMAN\\Don
vti_modifiedby:SR|FRONTPAGE\\Don
vti_nexttolasttimemodified:TW|18 Jun 2010 05:00:00 -0000
vti_timecreated:TR|22 Jan 2012 19:35:25 -0000
vti_extenderversion:SR|6.0.2.8161
vti_backlinkinfo:VX|
vti_syncwith_ftp.mathman.biz\:21:TW|25 Apr 2014 03:11:30 -0000
vti_syncofs_ftp.mathman.biz\:21:TW|18 Jun 2010 05:00:00 -0000
vti_cacheddtm:TX|25 Apr 2014 03:11:30 -0000
vti_filesize:IR|11340
