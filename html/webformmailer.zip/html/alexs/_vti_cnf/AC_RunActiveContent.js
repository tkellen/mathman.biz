vti_encoding:SR|utf8-nl
vti_timelastmodified:TW|09 Feb 2010 06:00:00 -0000
vti_author:SR|MATHMAN\\Don
vti_modifiedby:SR|MATHMAN\\Don
vti_nexttolasttimemodified:TW|09 Feb 2010 06:00:00 -0000
vti_timecreated:TR|22 Jan 2012 19:39:15 -0000
vti_cacheddtm:TX|22 Jan 2012 19:39:15 -0000
vti_filesize:IR|8613
vti_extenderversion:SR|6.0.2.5516
vti_backlinkinfo:VX|
vti_syncwith_ftp.mathman.biz\:21:TW|22 Jan 2012 19:39:15 -0000
vti_syncofs_ftp.mathman.biz\:21:TW|09 Feb 2010 06:00:00 -0000
