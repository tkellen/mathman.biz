#!/usr/bin/perl

#-------------------------------------------------------------#
# written by Terry Goodykoontz                                                                                                                                    #
#                                                                                                                                                                                              #
# Last up dated:                                                                                                                                                                 #
#                                                                                                                                                                                              #  
#-------------------------------------------------------------#

# Define fairly-constants
require "ctime.pl";

# This should match the mail program on your system.
$mailprog = '/usr/sbin/sendmail';

# This should be set to the username or alias that runs your WWW sever
$recipient = 'mathman@shout.net';

# Print out a content-type for HTTP/1.0 compatibility
print "Content-type: text/html\n\n";

# Get the input 
read(STDIN,$buffer, $ENV{'CONTENT_LENGTH'});

# Split the name-value pairs
@pairs = split(/&/, $buffer);

foreach $pair (@pairs)
{

	($name,$value) = split(/=/, $pair);

	# Un-Webify plus signs and %-encoding
 	$value =~ tr/+/ /;

        $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	# Stop people from using subshells to execute commands
	# Not a big deal when using sendmail, but very important
	# when using UCB mail (aka mailx) .
	# $value =~ s/~!/ ~!/g;

	# Uncomment for debugging purposes
	# print  "Setting $name to $value<P>";

	$FORM{$name} = $value

}



# If the comments are blank, then give a "blank form" response

&blank_response unless $FORM{'Name'} && $FORM{'TeleNum'} && $FORM{'Address'} && $FORM{'city'} && $FORM{'State'} && $FORM{'Zip'};

# if($FORM{'Send Order'} eq "Send Order"){
# 
#	&blank_response unless $FORM{'Name'};
#	&blank_response unless $FORM{'TeleNum'};
#	&blank_response unless $FORM{'Address'};
# 	&blank_response unless $FORM{'city'};
# 	&blank_response unless $FORM{'State'};
# 	&blank_response unless $FORM{'Zip'};

#}

#----------------------------------------------------------------#
# Now send mail to $recipient

open (MAIL, "|$mailprog $recipient")  || die "Can't open $mailprog!\n";
print MAIL "From: webmaster\n";
print MAIL "Subject: Mathman's Order Form\n\n";
print MAIL "Someone claiming to be $FORM{'Name'} sent the following : \n\n";
print MAIL "Name: $FORM{'Name'}\n";
print MAIL "Address: $FORM{'Address'}\n";
print MAIL "City: $FORM{'city'}\n";
print MAIL "State: $FORM{'State'}\n";
print MAIL "Country: $FORM{'Country'}\n";
print MAIL "Telephone: $FORM{'TeleNum'}\n";
print MAIL "E-Mail: $FORM{'Email'}\n\n";
print MAIL "Credit Card Number: $FORM{'Cardnum'}\n";
print MAIL "Expiration Date: $FORM{'Date'}\n\n";
print MAIL "$FORM{'Name'} is interested in ordering the following items.\n\n"; 
print MAIL "1. \"Calculas By and For Young People\": $FORM{'QTY1'}\n";
print MAIL "2. \"Calculas By and For Young People--Worksheets\": $FORM{'QTY2'}\n";
print MAIL "3. VT#1 \"Infinite Series By and For 6 years-olds and up\": $FORM{'QTY3'}\n";
print MAIL "4. VT#2 \"Iteration to Infinite Sequences with 6 to 11 years-olds\": $FORM{'QTY4'}\n";
print MAIL "5. \"A Map to Calculus\"--A 15\" x 18\" poster-map, overview: $FORM{'QTY5'}\n";
print MAIL "6. \"Changing Shapes With Matrices\": $FORM{'QTY6'}\n";
print MAIL "All 6 items above ordered together: $FORM{'QTY7'}\n";
print MAIL "Shipping and Handling: $FORM{'QTY8'}\n";
print MAIL "\"On Thinking About & Doing Mathematics\"--An 11\" x 17\" poster: $FORM{'QTY9'}\n";
print MAIL "SUB TOTAL: $FORM{'Sub_Total'}\n";
print MAIL "Tax: $FORM{'Tax'}\n";
print MAIL "TOTAL: $FORM{'Total'}\n\n";

print MAIL "Server protocol: $ENV{ 'SERVER_PROTOCOL' } \n";
print MAIL "Remote host: $ENV{ 'REMOTE_HOST' } \n";
print MAIL "Remote IP address: $ENV{ 'REMOTE_ADDR' }\n\n";
print MAIL "P.S. If you have any Questions about configuration of this ";
print MAIL "automated form report, please e-mail terry\@eurysis.com.\n";
close (MAIL);

# Make the person feel good for writing to us

print "<HEAD><TITLE> Thank you!</HEAD></TITLE>";
print "<HR><CENTER><H1>Thank you !</H1><P>";
print "Thank you for ordering from";
print "<I><B>The Mathman</B></I><P>";
print "<P>Your order has been email to us,";
print "and will be processed as soon as possible.";
print "<P>You may return to <A HREF=\"http://www.shout.net/~mathman/html/math.html\">";
print "<I>Mathman's</I> home page</A>, if you wish.</P></CENTER><HR>";

#------------------------------------------------------------#
# subroutine blank_response
sub blank_response
{
	print "<HEAD><TITLE>Incomplete Form</TITLE><HEAD>";
	print "<HR><CENTER><H1>Your Form is Incomplete</H1><P>";
	print"You appear to have left some information blank, and
	the form was not sent ";
	print "to us.<BR> Please complete the form (your name, address,
	city, state, and phone number are required)";
	print "<BR>or return to the <A HREF=\"http://www.shout.net/~mathman/html/math.html\">";
	print "<I>Mathman's</I> home page</A>.</CENTER><HR>";
	exit;
}

sub die
{
# 	print "Couldn't open file to log events....";
	print "<P><CENTER>Thank you for sending us your
	request!</CENTER></P>";
	print "<P><CENTER>You may return to <A 	HREF=\"http://www.shout.net/~mathman/html/math.html\">";
	print "<I>Mathman's</I> home page</A>, if you
	wish.</P></CENTER><HR>";
	exit;
}
